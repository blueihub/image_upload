<?php
class Dummy_image_model extends CI_Model
{
	public function upload($array)
	{
		return $this->db->insert('dummy_image',$array);
	}
}
?>