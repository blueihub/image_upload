
<h2>Upload Image Here</h2><hr>
<?php echo form_open_multipart('dummy_image_controller/upload',['class'=>'form-horizontal']);?>
<?php echo form_input(['type'=>'text','name'=>'title']);?>
<?php echo form_upload(['name'=>'userfile']);?><hr>
<?php echo form_submit(['name'=>'submit','class'=>'btn btn-danger','value'=>'Do upload']);?>

<?php echo form_close();?>