<?php
class Dummy_image_controller extends CI_Controller
{
	public function index()
	{
		$this->load->view('practice/dummy_image_upload');
	}


	public function upload()
	{
		 $config=[
					'upload_path'	=>	'./uploads',
					'allowed_types' =>	'jpg|gif|png|jpeg',
				 ];

		$this->load->library('upload',$config);
		 if($this->upload->do_upload('userfile'))
		 {
		 	
			$data = $this->upload->data();
		 	$image_path = base_url("uploads/" . $data['raw_name'] . $data['file_ext']);
		 	$title = $this->input->post('title');
		 	$data = array(
		 		'title'	=>	$title,
		 		'image'	=>	$image_path
		 	);

		 }
		 else
		 {
		 	echo "Not able to upload";
		 }

		 $this->load->model('dummy_image_model');
		 if($this->dummy_image_model->upload($data))
		 {
		 	echo "success";
		 }
		 else
		 {
		 	echo "failed";
		 }


	}
}

?>